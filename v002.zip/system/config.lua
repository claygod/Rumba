--[[
	Config
	The main configuration file
--]]

function genObj()

local M = {
	Engine = {
		copy = 'E.S.',
	},
}

return M
end